package com.cg.empapp.dao;

import java.util.HashMap;

import com.cg.empapp.dto.Employee;
import com.cg.empapp.exception.EmployeeException;

/**
 * class to perform business logic
 */
public class EmployeeDaoImpl implements EmployeeDao{
	
	/**
    * map to hold the data
    */
	private static HashMap<Integer,Employee> map=new HashMap<Integer,Employee>();
	Employee emp;
    
    
    /**
    * getter for map
    */   
    public static void setMap(HashMap<Integer,Employee> map)
    {
		EmployeeDaoImpl.map=map;
    }  
   
    /**
     * Setter for the map
     */

    public static HashMap<Integer,Employee> getMap()
    {
		return map;
    }

	@Override
	public void insertEmployee(Employee emp) {
		 
		map.put(emp.getEmpId(), emp);   //FOR INSERTING THE EMPLOYEES IN HASHMAP
		// TODO Auto-generated method stub
		
	}

	@Override
	public HashMap<Integer, Employee> getAllEmployees() throws EmployeeException {
		if(map.isEmpty()) {       //FOR GETTING OR RETRIVING ALL THE EMPLOYEE DETAILS IN THE MAP
			throw new EmployeeException("No Employee found");
		}
		else 
		{
			
			System.out.println(getMap());
		}
		
		return null;
	}

	@Override
	public Employee getEmployeeById(int id) throws EmployeeException {
		                         //FOR GETTING EMPLOYEE DETAILS BASED ON GIVEN ID
		
		Employee emp=map.get(id);
		if(map.containsKey(id)) {
			System.out.println(emp);	
			}
			else {
				throw new EmployeeException("there is no employee with that id:");
			}
		
		// TODO Auto-generated method stub
		

		return emp;  

	}
}

