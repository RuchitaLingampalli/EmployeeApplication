package com.cg.empapp.service;

import java.util.HashMap;
import java.util.Scanner;

import com.cg.empapp.dao.EmployeeDaoImpl;
import com.cg.empapp.dto.Employee;
import com.cg.empapp.exception.EmployeeException;

public class EmployeeServiceImpl implements EmployeeService
{
	Scanner sc=new Scanner(System.in);
   EmployeeDaoImpl d=new EmployeeDaoImpl();
	@Override
	public void insertEmployee(Employee emp) {
		                           
		                         
		d.insertEmployee(emp);   
		// TODO Auto-generated method stub
		
	}

	@Override
	public HashMap<Integer, Employee> getAllEmployees() throws EmployeeException {
		
		d.getAllEmployees();           
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Employee getEmployeeById(int id) throws EmployeeException {
		
		Employee emp=d.getEmployeeById(id);
		// TODO Auto-generated method stub
		return emp;
	}
	
	public boolean isEmpNameValid(String empName) {
		while(true)
		{
			if(empName.length()>=3 && Character.isUpperCase(empName.charAt(0)) )
			{
		return true;
	}
			else {
				System.out.println("INVALID NAME:");
				System.out.println("Enter again:");
				empName=sc.next();
			}
}
	}
		
		 public boolean isEmpSalValid(int empSal)
		  {
			  boolean b=false;
			  if(empSal>0)
				  b=true;
			 return b;
		  }
}