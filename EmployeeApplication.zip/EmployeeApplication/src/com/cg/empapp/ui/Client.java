package com.cg.empapp.ui;

import java.util.HashMap;
import java.util.Scanner;

import com.cg.empapp.dto.Employee;
import com.cg.empapp.exception.EmployeeException;
import com.cg.empapp.service.EmployeeServiceImpl;



public class Client {
	Scanner sc=new Scanner(System.in);
	//Main METHOD
	public static void main(String[] args) throws EmployeeException {
		int ch;
		char choice;
		
		HashMap<Integer,Employee> map=new HashMap<Integer,Employee>();
		EmployeeServiceImpl s=new EmployeeServiceImpl();
		Scanner sc=new Scanner(System.in);
		//FOR DISPLAYING MENU AND TAKING INPUTS 
		do {
		System.out.println("\n********Select an option*********\n 1.Add Employee  \n 2.Get All Employee Details \n 3.Get Employee Details By Id \n 4.exit");
		System.out.println("enter your choice:");
		ch=sc.nextInt();
		switch(ch) {
		case 1:
		System.out.println("enter employee id:");
		int empId=sc.nextInt();
		String empName;
		do {
		System.out.println("enter employee name:");
		 empName=sc.next();
		}
		while(!s.isEmpNameValid(empName)); //FOR NAME VALIDATION
		
		int empSal;
		do {
	   System.out.println("enter employee salary:");
		empSal=sc.nextInt();
		}while(!s.isEmpSalValid(empSal));  //FOR SALARY VALIDATION
		
		Employee emp=new Employee(empId,empName,empSal);
		s.insertEmployee(emp);
		System.out.println(emp);
		System.out.println("Employee details added successfully for "+emp.getEmpId());
		break;
		
		case 2:
			
			try {
			    System.out.println(s.getAllEmployees());
			} catch (EmployeeException e) {
			System.out.println(e);
			}
	
			
			break;
			
			
		case 3:
			System.out.println("Enter empId:");
			empId=sc.nextInt();
			
			try {
			    System.out.println(s.getAllEmployees());
			} catch (EmployeeException e) {
			System.out.println(e);
			}
			
			break;
			
		case 4:
			System.out.println("END");
			System.exit(0);
			break;
		}
		if(ch>4) 		
		System.out.println("ENTER A VALID OPTION");
		else 
		System.out.println("enter your choice(y/n):");
		choice=sc.next().charAt(0);
		if(choice =='y'||choice =='Y')
			continue;
		else {
			System.out.println("Thank you");
			System.exit(0);
		}
		}while(ch!=4);
		sc.close();
	}

	


	
		
		}
		


