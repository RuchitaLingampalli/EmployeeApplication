package com.cg.empapp.test;

import java.util.HashMap;

import org.junit.Test;

public class EmployeeDaoImplTest {
	                //FOR JUNIT TESTING

	@Test
	public void setMapTest() {
		HashMap map=new HashMap();
		//List l=new ArrayList();
		assert(map instanceof HashMap);
		//assert(map.isEmpty());
	}
}
